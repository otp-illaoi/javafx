package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class paziente {

    private StringProperty nome;
    private StringProperty cognome;
    private StringProperty idPaziente;
    private String medico; 
    private StringProperty telefono;

    public paziente(String idPaziente,String nome, String cognome, String telefono, String medico) {
    	this.idPaziente = new SimpleStringProperty(idPaziente);
        this.nome = new SimpleStringProperty(nome);
        this.cognome = new SimpleStringProperty(cognome); 
        this.telefono = new SimpleStringProperty(telefono);
        this.medico = medico;
    }

    public String getNome() {
        return nome.get();
    }

    public StringProperty nomeProperty() {
        return nome;
    }

    public String getCognome() {
        return cognome.get();
    }

    public StringProperty cognomeProperty() {
        return cognome;
    }

    public String getIdPaziente() {
        return idPaziente.get();
    }

    public String getMedico() {
        return medico;
    }

    public void setMedico(String medico) {
        this.medico = medico;
    }

    public String getTelefono() {
        return telefono.get();
    }

    public StringProperty telefonoProperty() {
        return telefono;
    }
    public void rimuoviDaMedico() {
        this.medico = null;
    }
    

}

