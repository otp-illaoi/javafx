
    package application;

    import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
    import java.io.IOException;
    import java.io.PrintWriter;
    import java.util.ArrayList;

    import javafx.event.ActionEvent;
    import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
    import javafx.scene.control.TextField;
    import javafx.stage.Stage;

    public class AddPatController {

        @FXML
        private TextField idField;

        @FXML
        private TextField nameField;

        @FXML
        private TextField cognomeField;

        @FXML
        private TextField telField;
        
        @FXML
        private TextField MEDICO;

        @FXML
        private Button add;

        @FXML
        private Button EXIT;

        private Stage stagee;

        private ArrayList<paziente> elencoPazienti;

        public void setStage(Stage stagee) {
            this.stagee = stagee;
        }

        @FXML
        private void initialize() {
            elencoPazienti = new ArrayList<>();
            add.setOnAction(event -> {
                String id = idField.getText();
                String name = nameField.getText();
                String cognome = cognomeField.getText();
                String tel = telField.getText();
                String MED = MEDICO.getText();

                if (pazienteEsiste(id)) {
                    System.out.println("Il paziente con ID " + id + " esiste gi�.");
                    return;
                }

                paziente nuovoPaziente = new paziente(name, cognome, id, tel,MED);
                elencoPazienti.add(nuovoPaziente);
                application.logger.scriviLog("Aggiunto paziente: " + nuovoPaziente.getNome() + " " + nuovoPaziente.getCognome());
                idField.clear();
                nameField.clear();
                cognomeField.clear();
                telField.clear();
                MEDICO.clear();
            });
        }

        private boolean pazienteEsiste(String id) {
            try (BufferedReader reader = new BufferedReader(new FileReader("dati_pazienti.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length > 0 && parts[0].equals(id)) {
                        return true; 
                    }
                }
            } catch (IOException e) {
                System.err.println("Errore durante la lettura del file dati_pazienti.txt: " + e.getMessage());
            }
            return false; 
        }


        @FXML
        private void chiudi(ActionEvent event) {
            salvaDatiSuFile();
            chiudiFinestra();
        }

        private void chiudiFinestra() {
        	if (stagee != null) {
    	        stagee.close();
    	        
    	        try {
    	            FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
    	            Parent root = loader.load();
    	            Scene scene = new Scene(root);
    	            Stage stage = new Stage();
    	            stage.setScene(scene);
    	            stage.show();
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    } else {
    	        System.err.println("Errore: stagee � null");
    	    }
        }

        private void salvaDatiSuFile() {
        	try (PrintWriter writer = new PrintWriter(new FileWriter("dati_pazienti.txt", true))) {
                for (paziente paziente : elencoPazienti) {
                    writer.println(paziente.getIdPaziente() + "," + paziente.getNome() + "," + paziente.getCognome() + "," + paziente.getTelefono()+ ","+paziente.getMedico());
                }
                System.out.println("Dati pazienti salvati su file.");
            } catch (IOException e) {
                System.err.println("Errore durante il salvataggio dei dati pazienti su file: " + e.getMessage());
            }
        }
    }

