package application;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class AddDoctorController {

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField cognomeField;
    @FXML
    private TextField telField;

    @FXML
    private Button add;
    
    @FXML
    private Button EXIT;

    private Stage stagee;
    
    private ArrayList<Medico> elencoMedici;

    public void setStage(Stage stagee) {
        this.stagee = stagee;
    }

    @FXML
    private void initialize() throws Exception {
    	elencoMedici = new ArrayList<>();
    	add.setOnAction(event -> {
    	    String id = idField.getText();
    	    String name = nameField.getText();
    	    String cognome = cognomeField.getText();
    	    String tel = telField.getText();

    	   
    	    boolean medicoEsiste = medicoPresente(id);

    	    if (!medicoEsiste) {
    	        Medico nuovoMedico = new Medico(id, name, cognome, tel);
    	        elencoMedici.add(nuovoMedico); 
    	        application.logger.scriviLog("Aggiunto medico: " + nuovoMedico.getNome() + " " + nuovoMedico.getCognome());       
    	        idField.clear();
    	        nameField.clear();
    	        cognomeField.clear();
    	        telField.clear();

    	        salvaDatiSuFile(); 
    	    } else {
    	        System.out.println("Il medico con ID " + id + " esiste gi�.");
    	       
    	    }
    	});
    }
    	private boolean medicoPresente(String id) {
    	    try (Scanner scanner = new Scanner(new File("dati_medici.txt"))) {
    	        while (scanner.hasNextLine()) {
    	            String[] medicoData = scanner.nextLine().split(",");
    	            String medicoId = medicoData[0];
    	            if (medicoId.equals(id)) {
    	                return true; 
    	            }
    	        }
    	    } catch (FileNotFoundException e) {
    	        System.err.println("Il file dati_medici.txt non � stato trovato.");
    	        e.printStackTrace();
    	    } catch (IOException e) {
    	        System.err.println("Errore durante la lettura del file dati_medici.txt.");
    	        e.printStackTrace();
    	    }
    	    return false; 
    	}

    @FXML
    private void chiudi(ActionEvent event) {

        chiudiFinestra();   
        }
    
    @FXML
    private void chiudiFinestra() {
    	 if (stagee != null) {
    	        stagee.close();
    	        
    	        try {
    	            FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
    	            Parent root = loader.load();
    	            Scene scene = new Scene(root);
    	            Stage stage = new Stage();
    	            stage.setScene(scene);
    	            stage.show();
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    } else {
    	        System.err.println("Errore: stagee � null");
    	    }
    }
    
    private void salvaDatiSuFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("dati_medici.txt", true))) {
            for (Medico medico : elencoMedici) {
                writer.println(medico.getIdMedico() + "," + medico.getNome() + "," + medico.getCognome() + "," + medico.getTelefono());
            }
            System.out.println("Dati aggiunti su file.");
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiunta dei dati su file: " + e.getMessage());
        }
    }
}

	
